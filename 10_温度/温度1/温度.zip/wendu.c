#include"ds18b20.h"
void zhaochi_main()		 
{

		readtemp();
		catch_temp1();
		readtemp(); 
		catch_temp2();
		
}